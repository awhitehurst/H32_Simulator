package masv;

import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author Adrian Sanchez
 */
public class OpcodeTable {
    
    private static final Map<String, Short> optable;
    
    static {
        optable = new TreeMap<>();
        optable.put("ld",(short)0x0000);
        optable.put("st",(short)0x1000);
        optable.put("add",(short)0x2000);
        optable.put("sub",(short)0x3000);
        optable.put("ldr",(short)0x4000);
        optable.put("str",(short)0x5000);
        optable.put("addr",(short)0x6000);
        optable.put("subr",(short)0x7000);
        optable.put("ldc",(short)0x8000);
        optable.put("ja",(short)0x9000);
        optable.put("jzop",(short)0xA000);
        optable.put("jn",(short)0xB000);
        optable.put("jz",(short)0xC000);
        optable.put("jnz",(short)0xD000);
        optable.put("call",(short)0xE000);
        optable.put("ret",(short)0xF000);
        optable.put("ldi",(short)0xF100);
        optable.put("sti",(short)0xF200);
        optable.put("push",(short)0xF300);
        optable.put("pop",(short)0xF400);
        optable.put("alocy",(short)0xF500);
        optable.put("dlocy",(short)0xF600);
        optable.put("swap",(short)0xF700);
        optable.put("uout",(short)0xFFF5);
        optable.put("sin",(short)0xFFF6);
        optable.put("sout",(short)0xFFF7);
        optable.put("hin",(short)0xFFF8);
        optable.put("hout",(short)0xFFF9);
        optable.put("ain",(short)0xFFFA);
        optable.put("aout",(short)0xFFFB);
        optable.put("din",(short)0xFFFC);
        optable.put("dout",(short)0xFFFD);
        optable.put("bkpt",(short)0xFFFE);
        optable.put("halt",(short)0xFFFF);
        
    }
    
    public static boolean isNmeumonic(String s){
        return optable.containsKey(s);
    }
        public static short getOpcode(String s){
            return optable.get(s.toLowerCase());
        }
    }
            
